************************
SayBack
v 0.2
April 22, 2012
Written by Ryan Moriarty
Built on Java Sound API JavaSoundDemo: http://java.sun.com/products/java-media/sound/samples/JavaSoundDemo/

You need Java installed on your computer to run SayBack.
You can download it from this link: http://java.com/en/download/index.jsp

1. Press the Record button in the top panel to record a word, then hit Stop
2. Press the Flip it! button to reverse the sound. 
3. Have somebody listen to the reversed sound.
4. Have that somebody attempt to reproduce the sound in the bottom recorder
5. Press the Flip It! button in the bottom panel. The sound will now resemble the original word
6. The player must guess what the original word was before their score (at the bottom of the window) hits 0.

To save yoruself the trouble of recording a sound, press the Generate button to load up a pre-recorded word.
The initial word bank is small, but you can save your own by typing the word in the box at the bottom of the top panel and 
hitting the Save button.
